import hero from '../public/images/heros/hero-image_1.jpg';

class jumbotron extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
        <div class="jumbotron">
            <img src="${hero}" alt="hero-image_1">
        </div>`;
  }
}
customElements.define('nav-jumbotron', jumbotron);
